<?php
// Database connection
$ser = "localhost";
$uname = "root";
$pass = "";
$db = "floric";
$con = mysqli_connect($ser, $uname, $pass, $db);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Sign-Up Logic
    if (isset($_POST['sign_submit'])) {
        $username = $_POST['sign_uname'];
        $password = $_POST['sign_pswd'];
        $email = $_POST['sign_email'];
        $mobile = $_POST['sign_mob'];
        
        // Insert the sign-up data into the database
        $query = "INSERT INTO `users`(`username`, `password`, `email`, `mobile`) VALUES ('$username','$password','$email','$mobile')";
        if (mysqli_query($con, $query)) {
            setcookie('user', $username, time() + 3600, "/");  // Set cookie for 1 hour
            header("Location: dashboard.php?signup_success=1");
            exit();
        } else {
            echo "<h2>Error: " . $query . "<br>" . mysqli_error($con) . "</h2>";
        }
    }

    // Login Logic
    if (isset($_POST['log_submit'])) {
        $log_username = $_POST['log_uname'];
        $log_password = $_POST['log_pswd'];

        // Check the credentials from the database
        $query = "SELECT * FROM `users` WHERE username='$log_username' AND password='$log_password'";
        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) > 0) {
            // Login successful, set cookie
            setcookie('user', $log_username, time() + 3600, "/");  // Set cookie for 1 hour
            header("Location: dashboard.php");  // Redirect to dashboard
            exit();
        } else {
            // Invalid credentials
            echo "<h2>Invalid Username or Password. Please try again.</h2>";
        }
    }
}

// Success message after sign-up
if (isset($_GET['signup_success']) && $_GET['signup_success'] == 1) {
    echo "<h2>Sign-up successful! Welcome, " . htmlspecialchars($_COOKIE['user']) . ".</h2>";
}
?>
