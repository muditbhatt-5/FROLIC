<?php
// Unset the cookie and redirect to the login page
setcookie('user', '', time() - 3600, "/");  // Expire the cookie
header("Location: home.php");
exit();
?>
