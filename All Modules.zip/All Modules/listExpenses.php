<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "floric"; // Replace with your database name

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Add new expense
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_expense'])) {
    $description = $_POST['description'];
    $amount = $_POST['amount'];
    $paid_by = $_POST['paid_by'];
    $date = $_POST['date'];

    // Insert into database
    $sql = "INSERT INTO group_expenses (description, amount, paid_by, date) 
            VALUES ('$description', '$amount', '$paid_by', '$date')";

    if ($conn->query($sql) === TRUE) {
        echo "<p>Expense added successfully!</p>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Delete an expense
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM group_expenses WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        echo "<p>Expense deleted successfully!</p>";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Fetch all expenses
$sql = "SELECT * FROM group_expenses";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Group Expenses Management</title>
    <link rel="stylesheet" href="./assets/styles.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>

<!-- List of Expenses -->
<h2>List of Expenses</h2>
<table border="1">
    <tr>
        <th>ID</th>
        <th>Description</th>
        <th>Amount</th>
        <th>Paid By</th>
        <th>Date</th>
        <th>Action</th>
    </tr>
    <?php
    if ($result->num_rows > 0) {
        // Output data for each row
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['description'] . "</td>";
            echo "<td>" . $row['amount'] . "</td>";
            echo "<td>" . $row['paid_by'] . "</td>";
            echo "<td>" . $row['date'] . "</td>";
            echo "<td><a href='group_expenses.php?delete=" . $row['id'] . "'>Delete</a></td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='6'>No expenses found</td></tr>";
    }
    ?>
    <a type="submit" href="./dashboard.php" id="butto2"  class="btn btn-primary" name="add_expense" >Back</a>
</table>

</body>
</html>

<?php
// Close database connection
$conn->close();
?>
