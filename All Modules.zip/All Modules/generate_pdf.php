<?php
require('fpdf/fpdf.php');

// Database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "your_database"; 

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create instance of FPDF
$pdf = new FPDF();
$pdf->AddPage();

// Set font
$pdf->SetFont('Arial', 'B', 12);

// Add title
$pdf->Cell(0, 10, 'User Data Report', 0, 1, 'C');

// Add table header
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 10, 'Username', 1);
$pdf->Cell(60, 10, 'Email', 1);
$pdf->Cell(40, 10, 'Mobile', 1);
$pdf->Cell(0, 10, '', 0, 1, 'C');

// Fetch all users
$sql = "SELECT username, email, mobile FROM users";
$result = $conn->query($sql);

// Set font for table content
$pdf->SetFont('Arial', '', 10);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(40, 10, htmlspecialchars($row['username']), 1);
        $pdf->Cell(60, 10, htmlspecialchars($row['email']), 1);
        $pdf->Cell(40, 10, htmlspecialchars($row['mobile']), 1);
        $pdf->Cell(0, 10, '', 0, 1, 'C');
    }
} else {
    $pdf->Cell(0, 10, 'No data available', 1, 1, 'C');
}

// Close the database connection
$conn->close();

// Output the PDF
$pdf->Output();
?>

