<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$dbname = "floric"; 

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch expenses and members for the dropdowns
$expenses = $conn->query("SELECT id, description FROM expenses WHERE settled = 0");
$members = $conn->query("SELECT id, name FROM members");

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['record_payment'])) {
    $expense_id = $_POST['expense_id'];
    $member_id = $_POST['member_id'];
    $amount = $_POST['amount'];
    $payment_date = $_POST['payment_date'];

    // Insert payment record
    $sql = "INSERT INTO payments (expense_id, member_id, amount, payment_date) 
            VALUES ('$expense_id', '$member_id', '$amount', '$payment_date')";
    
    if ($conn->query($sql) === TRUE) {
        // Check if the expense is fully settled
        $settled_amount = $conn->query("SELECT SUM(amount) as total_paid FROM payments WHERE expense_id = $expense_id")->fetch_assoc()['total_paid'];
        $total_amount = $conn->query("SELECT amount FROM expenses WHERE id = $expense_id")->fetch_assoc()['amount'];
        
        if ($settled_amount >= $total_amount) {
            $conn->query("UPDATE expenses SET settled = 1 WHERE id = $expense_id");
        }
        
        echo "<p>Payment recorded successfully!</p>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Payment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Record Payment</h1>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="expense_id" class="form-label">Expense</label>
                <select class="form-select" id="expense_id" name="expense_id" required>
                    <option value="">Select an expense</option>
                    <?php while ($row = $expenses->fetch_assoc()): ?>
                        <option value="<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['description']); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="mb-3">
                <label for="amount" class="form-label">Amount</label>
                <input type="number" step="0.01" class="form-control" id="amount" name="amount" required>
            </div>
            <div class="mb-3">
                <label for="payment_date" class="form-label">Payment Date</label>
                <input type="date" class="form-control" id="payment_date" name="payment_date" required>
            </div>
            <button type="text" name="record_payment" class="btn btn-success">Payment Success</button>
        </form>
    </div>
</body>
</html>
