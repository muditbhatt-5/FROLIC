<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve data from POST request
    $amount = $_POST['amount'];
    $members = $_POST['members'];

    // Calculate amount per member
    if ($members > 0) {
        $amount_per_member = $amount / $members;
    } else {
        $amount_per_member = 0;
    }
} else {
    // Redirect to input page if accessed directly
    header('Location: input_page.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Result Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Calculation Result</h1>
        <p><strong>Total Amount:</strong> $<?php echo htmlspecialchars(number_format($amount, 2)); ?></p>
        <p><strong>Number of Members:</strong> <?php echo htmlspecialchars($members); ?></p>
        <p><strong>Amount per Member:</strong> $<?php echo htmlspecialchars(number_format($amount_per_member, 2)); ?></p>
        <a href="input_page.php" class="btn btn-primary mt-3">Go Back</a>
    </div>
</body>
</html>
